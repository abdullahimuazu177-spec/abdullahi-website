Abdullahi Muazu website update package

Upload these five website files to the root of the GitHub repository:
1. index.html
2. verify-credential.html
3. credential-qr.png
4. robots.txt
5. sitemap.xml

Do not upload this README file or the ZIP archive to the live website.
The index.html file includes 11 pricing packages, 60 book/document services, a self-issued certificate statement, and WhatsApp/email contact-choice buttons.
